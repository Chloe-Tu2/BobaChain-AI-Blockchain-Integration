# BobaChain Quick Start - Claude Haiku 4.5 & Transaction Signing

## ⚡ New Features Implemented

### 1. Claude Haiku 4.5 AI Integration ✅
AI-powered supply chain summaries via `/api/summary` endpoint.

### 2. Flexible Transaction Signing ✅
- Ganache unlocked accounts (default, no config needed)
- Private key signing (optional, for production)

### 3. Configuration Endpoint ✅
Clients can query active AI model via `/api/config`

---

## 🚀 Quick Start

### Enable Claude Haiku 4.5 (30 seconds)

**Step 1: Get API Key**
- Go to https://console.anthropic.com
- Generate API key

**Step 2: Set Environment Variable**

```powershell
# PowerShell
$env:CLAUDE_API_KEY = "sk-ant-your-key-here"

# Or create .env file
CLAUDE_API_KEY=sk-ant-your-key-here
```

**Step 3: Start Backend**
```powershell
cd backend
python app.py
```

**Step 4: Test It**
```powershell
# Check config
curl http://localhost:5000/api/config

# Get AI summary
curl http://localhost:5000/api/summary
```

---

## 🔧 Configuration Reference

| Environment Variable | Purpose | Example |
|---------------------|---------|---------|
| `CLAUDE_API_KEY` | Enable Claude Haiku 4.5 | `sk-ant-...` |
| `CLAUDE_API_URL` | Claude API endpoint | `https://api.anthropic.com/v1` |
| `BLOCKCHAIN_PROVIDER` | Blockchain RPC URL | `http://localhost:8545` |
| `BLOCKCHAIN_PRIVATE_KEY` | (Optional) Private key for signing | `0x...` |
| `BLOCKCHAIN_FROM_ADDRESS` | (Optional) Sender address | `0x...` |

---

## 📡 New API Endpoints

### GET /api/config
Check which AI model is active and system status.

```bash
curl http://localhost:5000/api/config
```

Response:
```json
{
  "ai_model": "claude-3-5-haiku-20241022",
  "claude_enabled": true,
  "blockchain_connected": true
}
```

### GET /api/summary (Enhanced)
Now uses Claude Haiku 4.5 if `CLAUDE_API_KEY` is set.

```bash
curl http://localhost:5000/api/summary
```

---

## 🐳 Docker Deployment with Claude

**Create `.env` file:**
```bash
CLAUDE_API_KEY=sk-ant-your-key-here
CLAUDE_API_URL=https://api.anthropic.com/v1
BLOCKCHAIN_PROVIDER=http://blockchain:8545
```

**Deploy:**
```bash
docker-compose up -d
```

**Verify:**
```bash
docker-compose logs backend | grep "Claude\|connected"
```

---

## 💰 Pricing & Costs

**Claude Haiku 4.5** (Most Affordable)
- Input: $0.80 per 1M tokens
- Output: $4 per 1M tokens
- Typical supply chain query: ~$0.001-0.002

See [anthropic.com/pricing](https://anthropic.com/pricing)

---

## 🔐 Security Checklist

- [ ] Never expose API key in frontend
- [ ] Add `.env` to `.gitignore`
- [ ] Use environment variables (not hardcoded)
- [ ] Rotate keys if compromised
- [ ] Monitor usage in Anthropic console

---

## 🧪 Transaction Signing

### Default (Ganache Unlocked Accounts)
```python
# No configuration needed
blockchain_service = BlockchainService()
blockchain_service.create_batch("Name", "Origin")  # Just works!
```

### Private Key Signing
```bash
export BLOCKCHAIN_PRIVATE_KEY=0x...
export BLOCKCHAIN_FROM_ADDRESS=0x...
python app.py
```

---

## ✅ What Works Now

- ✅ Create batches on real blockchain
- ✅ Add tracking steps
- ✅ Retrieve batch history
- ✅ Get AI summaries via Claude
- ✅ Auto-fallback to local summarization if Claude unavailable
- ✅ Flexible transaction signing
- ✅ Docker deployment
- ✅ 40+ unit tests
- ✅ Full error handling & validation

---

## 📚 Documentation

- **README.md** - Overview & setup instructions
- **IMPLEMENTATION_GUIDE.md** - Detailed technical documentation
- **.env.example** - Configuration template
- **backend/app.py** - API endpoint code with docstrings
- **backend/ai/assistant.py** - Claude integration code
- **backend/services/blockchain.py** - Blockchain service code

---

## 🆘 Troubleshooting

### "CLAUDE_API_KEY not set"
→ Make sure env var is exported/set before running

### "Claude API error: 401"
→ Invalid API key; regenerate from console.anthropic.com

### "Not connected to blockchain"
→ Ensure Ganache is running on port 8545

### "Transaction failed"
→ Check logs: `docker-compose logs backend`

---

## 🎯 Next Steps

1. ✅ Set `CLAUDE_API_KEY` environment variable
2. ✅ Start backend: `python app.py`
3. ✅ Test: `curl http://localhost:5000/api/config`
4. ✅ Create batches & get AI summaries
5. ✅ Deploy with `docker-compose up -d`

---

**Ready to use Claude Haiku 4.5 for supply chain analysis!** 🚀
