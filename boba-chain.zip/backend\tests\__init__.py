"""
Tests package for backend application.
Contains unit tests and integration tests for all backend components.
"""
